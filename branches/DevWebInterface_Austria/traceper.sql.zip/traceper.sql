-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 07 Eylül 2011 saat 13:53:31
-- Sunucu sürümü: 5.5.8
-- PHP Sürümü: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `traceper`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_car`
--

CREATE TABLE IF NOT EXISTS `traceper_car` (
  `car_id` int(11) NOT NULL AUTO_INCREMENT,
  `car_login` varchar(11) NOT NULL,
  `car_pw` varchar(11) NOT NULL,
  `caroptions` text NOT NULL,
  `car_name` text NOT NULL,
  `car_desc` text NOT NULL,
  `caroptions1` text NOT NULL,
  `caroptions2` text NOT NULL,
  `car_phone` text NOT NULL,
  PRIMARY KEY (`car_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `traceper_car`
--

INSERT INTO `traceper_car` (`car_id`, `car_login`, `car_pw`, `caroptions`, `car_name`, `car_desc`, `caroptions1`, `caroptions2`, `car_phone`) VALUES
(1, 'car1', 'car1', '2,8,5', 'car1', '', '3,2', '9', '004912345'),
(2, 'car2', 'car2', '4,3', 'car2', '', '8', '12,15', '00495678');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_caroptions`
--

CREATE TABLE IF NOT EXISTS `traceper_caroptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` char(255) DEFAULT NULL,
  `description` text NOT NULL,
  `sort` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `traceper_caroptions`
--

INSERT INTO `traceper_caroptions` (`id`, `Title`, `description`, `sort`) VALUES
(1, 'caroption1', '', 2),
(2, 'caroption2', '', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_car_log`
--

CREATE TABLE IF NOT EXISTS `traceper_car_log` (
  `car_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `all_options` text NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  `car_id` int(11) NOT NULL,
  `logdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`car_log_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Tablo döküm verisi `traceper_car_log`
--

INSERT INTO `traceper_car_log` (`car_log_id`, `all_options`, `userId`, `car_id`, `logdate`) VALUES
(1, '', 1, 23, '2011-09-06 16:09:12'),
(2, ',,2', 1, 23, '2011-09-06 16:14:43'),
(3, ',,2', 1, 23, '2011-09-06 16:15:54'),
(4, ',,1', 1, 0, '2011-09-07 11:00:00'),
(5, ',,2', 1, 0, '2011-09-07 11:09:25'),
(6, 'Resource id #15', 1, 1, '2011-09-07 11:27:10'),
(7, 'Resource id #15', 1, 1, '2011-09-07 11:49:44'),
(8, 'Resource id #15', 1, 1, '2011-09-07 11:51:14'),
(9, 'Resource id #15', 1, 1, '2011-09-07 11:54:10'),
(10, 'Resource id #15', 1, 1, '2011-09-07 14:10:32'),
(11, 'Resource id #15', 1, 1, '2011-09-07 14:11:37'),
(12, 'Resource id #15', 1, 1, '2011-09-07 14:18:24'),
(13, ',,2', 1, 1, '2011-09-07 14:25:02'),
(14, ',,2', 1, 1, '2011-09-07 14:44:10'),
(15, ',,2', 1, 1, '2011-09-07 16:30:13'),
(16, ',,2', 1, 1, '2011-09-07 16:31:57'),
(17, '2', 1, 1, '2011-09-07 16:50:05'),
(18, '1', 1, 1, '2011-09-07 16:51:29');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_friends`
--

CREATE TABLE IF NOT EXISTS `traceper_friends` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `friend1` int(11) DEFAULT NULL,
  `friend2` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`Id`),
  UNIQUE KEY `friend1` (`friend1`,`friend2`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED AUTO_INCREMENT=39 ;

--
-- Tablo döküm verisi `traceper_friends`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_groups`
--

CREATE TABLE IF NOT EXISTS `traceper_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Tablo döküm verisi `traceper_groups`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_invitedusers`
--

CREATE TABLE IF NOT EXISTS `traceper_invitedusers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `dt` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `unique_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_invitedusers`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_status_messages`
--

CREATE TABLE IF NOT EXISTS `traceper_status_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_message` varchar(128) DEFAULT NULL,
  `status_source` tinyint(4) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `locationId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Tablo döküm verisi `traceper_status_messages`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_upload`
--

CREATE TABLE IF NOT EXISTS `traceper_upload` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `latitude` decimal(8,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  `altitude` decimal(15,6) NOT NULL,
  `uploadTime` datetime NOT NULL,
  `publicData` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`) USING BTREE,
  KEY `new_index` (`userId`),
  KEY `index2` (`uploadTime`),
  KEY `publicData` (`publicData`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_upload`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_upload_rating`
--

CREATE TABLE IF NOT EXISTS `traceper_upload_rating` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT,
  `voting_count` int(10) unsigned NOT NULL DEFAULT '0',
  `points` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`upload_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_upload_rating`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_upload_user_relation`
--

CREATE TABLE IF NOT EXISTS `traceper_upload_user_relation` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upload_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `upload_id` (`upload_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_upload_user_relation`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_users`
--

CREATE TABLE IF NOT EXISTS `traceper_users` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `password` char(32) NOT NULL,
  `group` int(10) unsigned NOT NULL DEFAULT '0',
  `latitude` decimal(8,6) NOT NULL DEFAULT '0.000000',
  `longitude` decimal(9,6) NOT NULL DEFAULT '0.000000',
  `altitude` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `realname` varchar(80) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dataArrivedTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deviceId` varchar(64) DEFAULT NULL,
  `facebook_id` int(15) NOT NULL,
  `status_message` varchar(128) DEFAULT NULL,
  `status_source` tinyint(4) DEFAULT NULL,
  `status_message_time` datetime DEFAULT NULL,
  `dataCalculatedTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expiredate` datetime NOT NULL,
  `onlinestatus` int(1) NOT NULL,
  `user_withInDistance` float NOT NULL,
  `user_options1` text NOT NULL,
  `user_options2` text NOT NULL,
  `caroptions` text NOT NULL,
  `car_id` text NOT NULL,
  `all_options` text NOT NULL,
  `user_phone` text NOT NULL,
  `call_phone` text NOT NULL,
  `userIsValid` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `email` (`email`),
  KEY `dataArrivedTime` (`dataArrivedTime`),
  KEY `realname` (`realname`) USING BTREE,
  KEY `facebook_id` (`facebook_id`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='This is for mobile app users' AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `traceper_users`
--

INSERT INTO `traceper_users` (`Id`, `password`, `group`, `latitude`, `longitude`, `altitude`, `realname`, `email`, `dataArrivedTime`, `deviceId`, `facebook_id`, `status_message`, `status_source`, `status_message_time`, `dataCalculatedTime`, `expiredate`, `onlinestatus`, `user_withInDistance`, `user_options1`, `user_options2`, `caroptions`, `car_id`, `all_options`, `user_phone`, `call_phone`, `userIsValid`) VALUES
(1, '827ccb0eea8a706c4c34a16891f84e7b', 0, '49.920925', '22.868595', '32.868595', 'Test', 'test@traceper.com', '2011-06-22 23:46:33', '351751049911319', 0, '', 1, '2010-10-31 20:10:09', '2011-09-06 08:58:07', '2011-11-07 00:00:00', 0, 3, '', '', '1', '1', '1', '245', '245', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_user_candidates`
--

CREATE TABLE IF NOT EXISTS `traceper_user_candidates` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `realname` varchar(100) NOT NULL,
  `password` char(32) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `index_name` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_user_candidates`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_user_group_relation`
--

CREATE TABLE IF NOT EXISTS `traceper_user_group_relation` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `groupId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `userIdIndex` (`userId`),
  KEY `groupIdIndex` (`groupId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_user_group_relation`
--


-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `traceper_user_was_here`
--

CREATE TABLE IF NOT EXISTS `traceper_user_was_here` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `dataArrivedTime` datetime NOT NULL,
  `latitude` decimal(8,6) NOT NULL DEFAULT '0.000000',
  `altitude` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `longitude` decimal(9,6) NOT NULL DEFAULT '0.000000',
  `deviceId` varchar(64) NOT NULL DEFAULT '0',
  `dataCalculatedTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`Id`),
  KEY `new_index` (`userId`),
  KEY `time` (`dataArrivedTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Tablo döküm verisi `traceper_user_was_here`
--

